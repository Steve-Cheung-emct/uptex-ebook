#!/usr/bin/env python3
# -*- encoding -*-
#-*- coding:utf-8 -*-
import io
import sys
import urllib.request
#改變標準輸出的默認編碼為utf8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8') 
from collections import Counter

a = [x for x in open(r"./sh0.tex", "r", encoding="utf-8").read() if  19968<=ord(x)<=40943  or 13312<=ord(x)<=19893 ]
b = [x for x in open(r"./sh1.tex", "r", encoding="utf-8").read() if  19968<=ord(x)<=40943  or 13312<=ord(x)<=19893 ]

a = a + a + a 

all = a + b

c = Counter(all)

for x in c:
    if c[x] == 1:
        print("(CHARACTER H "+ str.upper(hex(ord(x))) )
        print("    (MAP")
        print("        (SELECTFONT D 3)")
        print("        (SETCHAR H " + str.upper(hex(ord(x))) + ")")
        print("        )")
        print("    )")



