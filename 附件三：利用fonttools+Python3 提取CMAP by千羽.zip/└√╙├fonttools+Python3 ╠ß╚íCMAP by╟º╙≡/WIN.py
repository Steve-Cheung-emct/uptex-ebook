# /bin/python
# _*_ encoding: utf-8 _*_
# for Windows 10
import io
import os
import sys
import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8') 
i=0
#print(datetime.datetime.now())
f = open("out.txt", "w", encoding="utf-8")
for line in open("FZXSSGBX.ttx", encoding="utf-8"):
    if( "CJK" in line ):
        columns = line.split('"')
        if len(columns) >= 4:
            i += 1
            if( "uni" in columns[3] ):
                uid = columns[3].replace('uni','')
                if(len(uid) >= 2):
                    uid = int(uid, 16)
                    if( uid > 10000 ):
                        #print(chr(uid))
                        f.write(chr(uid) + "  " + str(i) + "\n")
            elif( 'cid' in columns[3] ):
                uid = columns[3].replace('cid','')
                if(len(uid) >=2):
                    uid = int(uid)
                    if(uid > 10000):
                        #print(chr(uid))
                        f.write(chr(uid) + "  " + str(i) + "\n")
            
f.close()
#print(datetime.datetime.now())



#########################################################
# /bin/python
# _*_ encoding: utf-8 _*_
# for OS X

#import os
#import sys
#import datetime
#
#i=0
##print(datetime.datetime.now())
#f = open("out.x", "w")
#for line in open("FZXSSGBX.ttx", encoding="utf-8"):
#    if( "CJK" in line ):
#        columns = line.split('"')
#        if len(columns) >= 4:
#            i += 1
#            if( "uni" in columns[3] ):
#                uid = columns[3].replace('uni','')
#                if(len(uid) >= 2):
#                    uid = int(uid, 16)
#                    if( uid > 10000 ):
#                        #print(chr(uid))
#                        f.write(chr(uid) + "  " + str(i) + "\n")
#            elif( 'cid' in columns[3] ):
#                uid = columns[3].replace('cid','')
#                if(len(uid) >=2):
#                    uid = int(uid)
#                    if(uid > 10000):
#                        #print(chr(uid))
#                        f.write(chr(uid) + "  " + str(i) + "\n")
#            
#f.close()
##print(datetime.datetime.now())
#