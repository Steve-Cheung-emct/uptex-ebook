python OSX.py  > ./col.txt
